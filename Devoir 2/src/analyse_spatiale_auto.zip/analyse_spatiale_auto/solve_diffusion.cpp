#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

typedef double T;

// résolution spatiale
constexpr int N = 300;

// paramètre remplacé par le script bash
constexpr T dt = YYYY;

constexpr T tf = 1.0;
constexpr T Deff = 1.0;
constexpr T k = 1.0;
constexpr T Ce = 1.0;
constexpr T R = 1.0;

// solution MMS
T C_exact(T r, T t)
{
    return exp(-t)*Ce*pow(r/R,3);
}

// terme source MMS
T source(T r, T t)
{
    T C = C_exact(r,t);

    T Ct = -C;
    T Cr = 3*Ce*exp(-t)*pow(r,2)/(R*R*R);
    T Crr = 6*Ce*exp(-t)*r/(R*R*R);

    return Ct - Deff*(Crr + Cr/r) + k*C;
}

int main()
{

    vector<T> r(N);
    T dr = R/(N-1);

    for(int i=0;i<N;i++)
        r[i]=i*dr;

    vector<vector<T>> A(N, vector<T>(N,0));
    vector<T> C(N,0);
    vector<T> b(N);

    T alpha = Deff*dt;

    // assemblage matrice
    for(int i=1;i<N-1;i++)
    {
        T ri = r[i];

        A[i][i-1] = alpha*(1/(2*ri*dr) - 1/(dr*dr));
        A[i][i]   = 1 + 2*alpha/(dr*dr) + k*dt;
        A[i][i+1] = alpha*(-1/(2*ri*dr) - 1/(dr*dr));
    }

    // centre
    A[0][0]=-3;
    A[0][1]=4;
    A[0][2]=-1;

    // surface
    A[N-1][N-1]=1;

    int Nt = round(tf/dt);
    T t=0;

    for(int n=0;n<Nt;n++)
    {
        t+=dt;

        b=C;

        for(int i=1;i<N-1;i++)
            b[i]+=source(r[i],t)*dt;

        b[0]=0;
        b[N-1]=C_exact(R,t);

        // résolution 
        for(int iter=0;iter<200;iter++)
        {
            for(int i=1;i<N-1;i++)
            {
                C[i]=(b[i]
                -A[i][i-1]*C[i-1]
                -A[i][i+1]*C[i+1])/A[i][i];
            }
        }
    }

    // erreur Linf
    T err=0;

    for(int i=0;i<N;i++)
    {
        T e=fabs(C[i]-C_exact(r[i],tf));
        err=max(err,e);
    }

    cout<<"The absolute error = "<<err<<endl;

}